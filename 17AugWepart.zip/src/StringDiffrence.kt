fun main(){
    val str1 = "122"
    val str2 = "100"
    val sum = str1.toInt()-str2.toInt()
    println(sum)
}