fun main() {
    var name = "Manohar"
    println(name)
    name = "Amol"
    println(name)
}
