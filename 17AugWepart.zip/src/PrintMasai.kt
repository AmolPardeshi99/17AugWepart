fun main() {
    println("Masai School")
}