fun main(){
    val side = 4;
    println("Perimeter is "+side*4)
}