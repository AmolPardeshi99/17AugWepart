fun main() {
    val num = 3
    for (i in 1..num) for (j in 1..i) println("$i.$j")
}