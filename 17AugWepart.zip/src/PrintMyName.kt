fun main() {

    val name = "Amol Pardeshi"
    println(name)
}