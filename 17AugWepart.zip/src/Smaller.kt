fun main(){
    val num1 =  5
    val num2 =  6
    if(num1>num2)  println(num2) else print(num1)
}
