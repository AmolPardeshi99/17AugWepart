fun main(){
    val num = 15;
    if (num%2==1) println("Odd Number")
}