fun main() {
    val x = 15
    println(divisible(x))
}

fun divisible(x: Int): Boolean = (x % 5 == 0)